"use client";

const CopyText = () => {
  // This component can be as simple as:
  return (
    <div
    className="fixed bottom-5 right-5 bg-green-600 text-white p-3 rounded shadow transition-opacity duration-300"
    >
        Копирано
    </div>
  );
};

export default CopyText;
